import javax.swing.*;

public class PozdravljenSwing {

  private static void narediInPokaziGUI() {

    // Naredi okno
    JFrame frame = new JFrame("PozdravljenSwing");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Dodaj pozdravno besedilo
    JLabel besedilo = new JLabel("Pozdravljen Swing!");
    frame.getContentPane().add(besedilo);

    // Pokazi okno
    frame.pack();
    frame.setVisible(true);
  }

  public static void main(String[] args) {
    narediInPokaziGUI();
  }
}
