/* Okno programa */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VnesiAvtoOkno extends JFrame implements ActionListener {

	private Avto avto;
	private JLabel naslov;
	private GlavnoOkno glavnoOkno;
	private JButton gumbShraniAvto;
	private JTextField poljePrestava;
	private JTextField poljeHitrost;
	private JPanel plosca;

	public VnesiAvtoOkno(Avto enAvto, GlavnoOkno okno) {

		setAvto(enAvto);
		glavnoOkno = okno;

		getContentPane().setLayout(new BorderLayout());

		naslov = new JLabel(" Vnesi polja, shrani avto ter zapri okno ...");
		getContentPane().add(naslov, BorderLayout.PAGE_END);

		plosca = new JPanel();
		getContentPane().add(plosca, BorderLayout.PAGE_START);

		plosca.add(new JLabel("Prestava = "));
		poljePrestava = new JTextField(20);
		plosca.add(poljePrestava);

		plosca.add(new JLabel("Hitrost = "));
		poljeHitrost = new JTextField(20);
		plosca.add(poljeHitrost);

		gumbShraniAvto = new JButton("Shrani avto");
		plosca.add(gumbShraniAvto);
		gumbShraniAvto.addActionListener(this);

		setTitle("Vnos novega avta");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}

	public void actionPerformed(ActionEvent e) {

		Object m = e.getSource();;
		Avto noviAvto = null;;
		if (m == gumbShraniAvto) {
			try {
				noviAvto = new Avto();
				noviAvto.setPrestava(Integer.parseInt(poljePrestava.getText()));
				noviAvto.setHitrost(Integer.parseInt(poljeHitrost.getText()));
				setAvto(noviAvto);
				glavnoOkno.getTekstnoOkno().append("" + noviAvto + "\n");
				poljePrestava.setText("");
				poljeHitrost.setText("");
			} catch (Exception e1) {
				glavnoOkno.getTekstnoOkno().append("Napaka - poskusite znova!\n");
			}
		}

	}

	public void setAvto(Avto avto) {
		this.avto = avto;
	}

	public Avto getAvto() {
		return avto;
	}

}
