/* Glavni program */

import javax.swing.*;

public class Parkirisce {

	private Avto[] avtomobili; 

	public Parkirisce(int velikost) {
		setAvtomobili(new Avto[velikost]);
	} 

	public static void main(String[] args) {
		Parkirisce mojeParkirisce = new Parkirisce(2);
		GlavnoOkno okno = new GlavnoOkno(mojeParkirisce);
		okno.pack();
		okno.setVisible(true);
	}

	public void setAvtomobili(Avto[] avtomobili) {
		this.avtomobili = avtomobili;
	}

	public Avto[] getAvtomobili() {
		return avtomobili;
	}

}
