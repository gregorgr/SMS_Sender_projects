import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Avto { 

  private int prestava; 
  private int hitrost; 

  public Avto() { 
    prestava = 0; 
    hitrost = 0;
  } 

  public Avto(int zacPrestava, int zacHitrost) { 
    prestava = zacPrestava; 
    hitrost = zacHitrost; 
  } 

  public int getPrestava() { 
    return prestava; 
  }

  public void setPrestava(int vrednost) { 
	  prestava = vrednost; 
  } 

  public int getHitrost() { 
    return hitrost; 
  } 

  public void setHitrost(int vrednost) { 
	  hitrost = vrednost; 
  } 

 
  public String toString() {
    String str = "Avto: [Prestava = " + this.prestava + "; "
                      + "Hitrost = " + this.hitrost + "]";
    return str;
  }

  public Avto copy() {
    Avto kopija = new Avto();
    kopija.prestava = this.prestava;
    kopija.hitrost = this.hitrost;
    return kopija;
  }

  public boolean isEqual(Avto avto) {
    if ((avto.prestava == this.prestava) &&
        (avto.hitrost == this.hitrost)) {
      return true;
    } else {
      return false;
    }
  }

  public static Avto vnesiAvto() throws Exception {
	  BufferedReader vhod = new BufferedReader( 
			  new InputStreamReader(System.in)); 
	  Avto noviAvto = new Avto(); 
	  System.out.println("Vnos novega avta:"); 
	  System.out.print("  Vnesi prestavo: "); 
	  String niz = vhod.readLine(); 
	  noviAvto.setPrestava(Integer.parseInt(niz)); 
	  System.out.print("  Vnesi hitrost: "); 
	  niz = vhod.readLine(); 
	  noviAvto.setHitrost(Integer.parseInt(niz));
	  return noviAvto;
  }

}