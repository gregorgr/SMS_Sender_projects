/* Glavno okno programa */

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class GlavnoOkno extends JFrame implements ActionListener {
	
	private JLabel naslov;
	private JButton gumbVnesiAvto1;
	private JButton gumbVnesiAvto2;
	private JButton gumbKoncaj;
	private JPanel plosca;
	private JScrollPane zvitek = new JScrollPane();
	private JTextArea tekstnoOkno = new JTextArea();
	private Parkirisce parkirisce;

	public GlavnoOkno(Parkirisce park) {

		setParkirisce(park);

		getContentPane().setLayout(new BorderLayout());
		
		naslov = new JLabel(" Pritisni ustrezen gumb ...");
		getContentPane().add(naslov, BorderLayout.PAGE_END);

		plosca = new JPanel();
		getContentPane().add(plosca, BorderLayout.PAGE_START);

		gumbVnesiAvto1 = new JButton("Vnesi avto 1");
		plosca.add(gumbVnesiAvto1);
		gumbVnesiAvto1.addActionListener(this);
		
		gumbVnesiAvto2 = new JButton("Vnesi avto 2");
		plosca.add(gumbVnesiAvto2);
		gumbVnesiAvto2.addActionListener(this);
		
		gumbKoncaj = new JButton("Koncaj");
		plosca.add(gumbKoncaj);
		gumbKoncaj.addActionListener(this);
		
		zvitek.setAutoscrolls(true);
	    getContentPane().add(zvitek, BorderLayout.CENTER);
	    zvitek.getViewport().add(tekstnoOkno);
		
		setSize(new Dimension(400, 400));
		setTitle("Glavno okno programa");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void actionPerformed(ActionEvent e) {
		Object m = e.getSource();;
		if (m == gumbVnesiAvto1) {
			Avto noviAvto = null;
			try {
				JFrame oknoVnesiAvto1 = new VnesiAvtoOkno(noviAvto, this);
				oknoVnesiAvto1.pack();
				oknoVnesiAvto1.setVisible(true);
				parkirisce.getAvtomobili()[0] = noviAvto;
			} catch (Exception e1) {
				getTekstnoOkno().append("Napaka - poskusite znova!\n");
			}
		} else if (m == gumbVnesiAvto2) {
			Avto noviAvto = null;
			try {
				JFrame oknoVnesiAvto2 = new VnesiAvtoOkno(noviAvto, this);
				oknoVnesiAvto2.pack();
				oknoVnesiAvto2.setVisible(true);
				parkirisce.getAvtomobili()[0] = noviAvto;
			} catch (Exception e1) {
				getTekstnoOkno().append("Napaka - poskusite znova!\n");
			}
		} else if (m == gumbKoncaj) {
			System.exit(0);
		}
	}

	public void setParkirisce(Parkirisce parkirisce) {
		this.parkirisce = parkirisce;
	}

	public Parkirisce getParkirisce() {
		return parkirisce;
	}

	public JTextArea getTekstnoOkno() {
		return tekstnoOkno;
	}

}
