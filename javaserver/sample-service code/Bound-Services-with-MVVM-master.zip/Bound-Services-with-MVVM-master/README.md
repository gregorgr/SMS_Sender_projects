# Bound-Services-with-MVVM
A simple example of how to bind a service while using MVVM

<a href="https://codingwithmitch.com/blog/bound-services-on-android/" target="_blank">Read the blog post</a>

Or 

<a href="https://www.youtube.com/watch?v=_xNkVNaC9AI" target="_blank">Watch the video</a>

##### Note: The structure of this project goes against the recommendation of a Google developer. See <a href="https://medium.com/androiddevelopers/viewmodels-and-livedata-patterns-antipatterns-21efaef74a54" target="_blank">this post</a> for more information.
